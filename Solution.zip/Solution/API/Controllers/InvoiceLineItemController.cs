﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Models;

namespace API.Controllers
{
	//[Route("api/v{version:apiVersion}/invoicelineitems")]
	[Route("api/[controller]")]
	public class InvoiceLineItemController : ControllerBase
	{
		private readonly AppDbContext _context;

		public InvoiceLineItemController(AppDbContext context)
		{
			_context = context;
		}

		// GET: api/v1/invoicelineitems
		[HttpGet]
		public async Task<ActionResult<IEnumerable<InvoiceLineItem>>> GetInvoiceLineItems()
		{
			return await _context.InvoiceLineItems.ToListAsync();
		}

		// GET: api/v1/invoicelineitems/5
		[HttpGet("{id}")]
		public async Task<ActionResult<InvoiceLineItem>> GetInvoiceLineItem(int id)
		{
			var invoiceLineItem = await _context.InvoiceLineItems.FindAsync(id);

			if (invoiceLineItem == null)
			{
				return NotFound();
			}

			return invoiceLineItem;
		}

		// POST: api/v1/invoicelineitems
		[HttpPost]
		public async Task<ActionResult<InvoiceLineItem>> CreateInvoiceLineItem(InvoiceLineItem invoiceLineItem)
		{
			_context.InvoiceLineItems.Add(invoiceLineItem);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetInvoiceLineItem), new { id = invoiceLineItem.Id }, invoiceLineItem);
		}

		// PUT: api/v1/invoicelineitems/5
		[HttpPut("{id}")]
		public async Task<IActionResult> UpdateInvoiceLineItem(int id, InvoiceLineItem invoiceLineItem)
		{
			if (id != invoiceLineItem.Id)
			{
				return BadRequest();
			}

			_context.Entry(invoiceLineItem).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!InvoiceLineItemExists(id))
				{
					return NotFound();
				}
				else
				{
					throw;
				}
			}

			return NoContent();
		}

		// DELETE: api/v1/invoicelineitems/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteInvoiceLineItem(int id)
		{
			var invoiceLineItem = await _context.InvoiceLineItems.FindAsync(id);
			if (invoiceLineItem == null)
			{
				return NotFound();
			}

			_context.InvoiceLineItems.Remove(invoiceLineItem);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool InvoiceLineItemExists(int id)
		{
			return _context.InvoiceLineItems.Any(i => i.Id == id);
		}
	}
}
