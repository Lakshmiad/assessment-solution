﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Models;

namespace API.Controllers
{
	//[Route("api/v{version:apiVersion}/customeraddresses")]
	[Route("api/[controller]")]
	public class CustomerAddressController : ControllerBase
	{
		private readonly AppDbContext _context;

		public CustomerAddressController(AppDbContext context)
		{
			_context = context;
		}

		// GET: api/v1/customeraddresses
		[HttpGet]
		public async Task<ActionResult<IEnumerable<CustomerAddress>>> GetCustomerAddresses()
		{
			return await _context.CustomerAddresses.ToListAsync();
		}

		// GET: api/v1/customeraddresses/5
		[HttpGet("{id}")]
		public async Task<ActionResult<CustomerAddress>> GetCustomerAddress(int id)
		{
			var customerAddress = await _context.CustomerAddresses.FindAsync(id);

			if (customerAddress == null)
			{
				return NotFound();
			}

			return customerAddress;
		}

		// POST: api/v1/customeraddresses
		[HttpPost]
		public async Task<ActionResult<CustomerAddress>> CreateCustomerAddress(CustomerAddress customerAddress)
		{
			_context.CustomerAddresses.Add(customerAddress);
			await _context.SaveChangesAsync();

			return CreatedAtAction(nameof(GetCustomerAddress), new { id = customerAddress.Id }, customerAddress);
		}

		// PUT: api/v1/customeraddresses/5
		[HttpPut("{id}")]
		public async Task<IActionResult> UpdateCustomerAddress(int id, CustomerAddress customerAddress)
		{
			if (id != customerAddress.Id)
			{
				return BadRequest();
			}

			_context.Entry(customerAddress).State = EntityState.Modified;

			try
			{
				await _context.SaveChangesAsync();
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!CustomerAddressExists(id))
				{
					return NotFound();
				}
				else
				{
					throw;
				}
			}

			return NoContent();
		}

		// DELETE: api/v1/customeraddresses/5
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteCustomerAddress(int id)
		{
			var customerAddress = await _context.CustomerAddresses.FindAsync(id);
			if (customerAddress == null)
			{
				return NotFound();
			}

			_context.CustomerAddresses.Remove(customerAddress);
			await _context.SaveChangesAsync();

			return NoContent();
		}

		private bool CustomerAddressExists(int id)
		{
			return _context.CustomerAddresses.Any(ca => ca.Id == id);
		}
	}
}
