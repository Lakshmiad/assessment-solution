1) Please update DefaultConnection in "appsettings.json" file and do migration.
