﻿using System.ComponentModel.DataAnnotations;

namespace API.Models
{
	public class CustomerAddress
	{
		[Key]
		public int Id { get; set; }

		[Required]
		public int CustomerId { get; set; }

		public string BillingAddress { get; set; }

		public string ShippingAddress { get; set; }

	}
}
