﻿using Microsoft.EntityFrameworkCore;

namespace API.Models
{
	public class AppDbContext : DbContext
	{
		public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
		{
		}

		public DbSet<Customer> Customers { get; set; }
		public DbSet<CustomerAddress> CustomerAddresses { get; set; }
		public DbSet<Invoice> Invoices { get; set; }
		public DbSet<InvoiceLineItem> InvoiceLineItems { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			// Add any additional configurations for your entities if needed
		}
	}
}
