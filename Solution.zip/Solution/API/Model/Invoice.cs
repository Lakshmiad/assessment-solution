﻿using System;
using System.ComponentModel.DataAnnotations;

namespace API.Models
{
	public class Invoice
	{
		[Key]
		public int Id { get; set; }

		[Required]
		public int CustomerId { get; set; }

		public DateTime InvoiceDate { get; set; }

	}
}
