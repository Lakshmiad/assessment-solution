﻿using System.ComponentModel.DataAnnotations;
namespace API.Models
{
	public class InvoiceLineItem
	{
		[Key]
		public int Id { get; set; }

		[Required]
		public int InvoiceId { get; set; }

		public string ProductName { get; set; }

		public decimal Price { get; set; }

	}
}
