﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace WordCountApp
{
	public partial class MainWindow : Window
	{
		private string[] words; // Array to store unique words from the file
		private string fileContents; // Variable to store the contents of the file

		public MainWindow()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

			bool? result = openFileDialog.ShowDialog();

			if (result == true)
			{
				string filePath = openFileDialog.FileName;
				if (!File.Exists(filePath))
				{
					MessageBox.Show("Selected file does not exist.");
					return;
				}

				FileNameTextBox.Text = filePath;

				// Read the contents of the file
				fileContents = File.ReadAllText(filePath);

				// Extract words from the file and count occurrences
				var wordOccurrences = CountWords(fileContents);

				// Populate FlowDocumentReader with file contents
				Paragraph paragraph = new Paragraph(new Run(fileContents));
				this.FlowDocReader.Document = new FlowDocument(paragraph);

				// Populate ComboBox with unique words
				words = wordOccurrences.Keys.ToArray();
				ComboBox.ItemsSource = words;

				// Clear word count textbox when a new file is selected
				WordCountTextBox.Text = "";
			}
		}

		private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ComboBox.SelectedValue != null)
			{
				string selectedWord = (string)ComboBox.SelectedValue;
				int wordCount = CountWords(fileContents)[selectedWord];
				WordCountTextBox.Text = $"{wordCount}";
			}
		}

		private Dictionary<string, int> CountWords(string text)
		{
			// Convert text to lowercase and remove punctuation and non-alphanumeric characters
			string cleanedText = Regex.Replace(text.ToLower(), @"[^a-zA-Z0-9\s]", "");

			// Remove dots and add spaces after each period
			cleanedText = cleanedText.Replace(".", ". ");

			// Use regular expression to split the cleaned text into words based on word boundaries and punctuation
			string[] allWords = Regex.Matches(cleanedText, @"\b[\w']+\b")
									.Cast<Match>()
									.Select(m => m.Value)
									.ToArray();

			// Count occurrences of each word
			Dictionary<string, int> wordOccurrences = new Dictionary<string, int>();
			foreach (string word in allWords)
			{
				if (wordOccurrences.ContainsKey(word))
					wordOccurrences[word]++;
				else
					wordOccurrences[word] = 1;
			}

			return wordOccurrences;
		}

	}
}
